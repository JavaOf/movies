import React from 'react'

export const Forgot = () => {
  return (
    <div>Forgot</div>
  )
}
